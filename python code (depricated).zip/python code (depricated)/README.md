This is where Commits will be made for the 'Compass' Senior project.
