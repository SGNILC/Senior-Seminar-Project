import React from 'react';
import './App.css';
import Signup from './Component/signup';
import Login from './Component/login';

function App() {
  return  <div><Signup /> </div>;
}

export default App;