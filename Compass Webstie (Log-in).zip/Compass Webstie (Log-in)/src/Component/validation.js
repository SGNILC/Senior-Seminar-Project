// const form = document.getElementById('form')
// const username_input = document.getElementById('username-input')
// const email_input = document.getElementById('email-input')
// const password_input = document.getElementById('password-input')
// const repeat_passowrd_input = document.getElementById('repeart-password-input')
// const error_message = document.getElementById('error-message')
// const allInputes = [username_input, email_input, password_input, repeat_passowrd_input]

// form.addEventListener('submit', (e) => {

//     let errors = []
//     if(username_input){
//         errors = getSignupFormErrors(username_input.value,email_input.value, password_input.value, repeat_passowrd_input.value)
//     }
//     else{
//         errors = getSignupFormErrors(email_input.value, password_input.value)
//     }
//     if (errors.length > 0){
//         e.preventDefault
//         error_message.innerText = errors.join(". ")
//     }

// })

// function getSignupFormErrors(username, email,  password, repeatpass){
//     if (username === '' || username == null){
//         error.push('Please enter your username')
//         username_input.parentElement.classList.add('incorect')
//     }
//     if (email === '' || email == null){
//         error.push('Please enter your username')
//         email_input.parentElement.classList.add('incorect')
//     }
//     if (password === '' || password == null){
//         error.push('Please enter your username')
//         password_input.parentElement.classList.add('incorect')
//     }
//     if (password !== repeatpass){
//         error.push('Paswords do not match. Please try again.')
//     }

//     return errors
// }

// allInputes.forEach(input => {
//     input.addEventListener('input', () => {
//         if(input.parentElement.classList.contains('incorrect')){
//             input.parentElement.classList.remove('incorrect')
//             error_message.innerText = ''
//         }

//     })
// })