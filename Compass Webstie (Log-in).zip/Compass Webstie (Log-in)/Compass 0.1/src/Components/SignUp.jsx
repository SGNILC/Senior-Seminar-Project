//import React, { Component } from 'react';
import "./LogIn.css"

function SignUp() {
   // Source:  https://medium.com/@kenaszogara/tutorial-create-simple-login-form-with-reactjs-31965ed3ccfa
        return (
      <>
      <div className="login">
            <h4 > Sign Up </h4>
             <form>
               <div className="text_area">
                 <input
                   type="text"
                   id="username"
                   name="First Name"
                   defaultValue="First Name"
                   className="text_input"
                 />
               </div>
               <div className="text_area">
                 <input
                   type="password"
                   id="password"
                   name="password"
                   defaultValue="password"
                   className="text_input"
    
                 />
               </div>
               <input
                 type="submit"
                 value="LOGIN"
                 className="btn"
               />
             </form>
             <a className="link" href="./LogIn">Sign Up</a>
           </div>
        </>
        )
      }
// function goToLogIn() {
//   return window.location.href = "src\Components\LogIn.jsx";
// }
export default SignUp;