// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
import './App.css'
import LogIn from './Components/LogIn'
import SignUp from './Components/Signup'
import { BrowserRouter as Router, Route, Switch, Routes } from 'react-router-dom'

function App() {
  return (
  <>
  <Router>
      <Routes>
        <Route index element={<LogIn />} />
        <Route path="/singup" element={<SignUp />} />
      </Routes>
  </Router>
    </>
  )
}
export default App
