import LogIn from "../Components/LogIn";

//import React, { Component } from 'react';
//import "./LogIn.css"
// import SignUp from "./Signup"
// import { Link } from 'react-router-dom'

function LogIn() {
    // Source:  https://medium.com/@kenaszogara/tutorial-create-simple-login-form-with-reactjs-31965ed3ccfa
 //    <Router>
 //    <Switch>
 //      <Route path="/login" component={LogIn} />
 //      <Route path="/singup" component={SignUp} />
 //    </Switch>
 //  </Router>
 
    return (
     <div>
       <form>
 <div className="text_area">
   <input
     type="text"
     id="username"
     name="username"
     defaultValue="username"
     className="text_input"
   />
 </div>
 <div className="text_area">
   <input
     type="password"
     id="password"
     name="password"
     defaultValue="password"
     className="text_input"
   />
 </div>
 <input
   type="submit"
   value="LOGIN"
   className="btn"
 />
 </form>
 <a className="link">Sign Up</ a>
     </div>
   )
 }
 export default LogIn;
 